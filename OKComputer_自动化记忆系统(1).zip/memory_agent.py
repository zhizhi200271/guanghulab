"""
智能记忆Agent系统
================
一个自动化的记忆管理系统，支持：
1. 关键词触发的记忆存储
2. 每次对话自动检索记忆
3. 持久化存储

作者: AI Assistant
版本: 1.0.0
"""

import json
import os
import re
from datetime import datetime
from typing import List, Dict, Optional, Tuple


class MemoryAgent:
    """
    自动化记忆Agent系统
    - 自动检索用户记忆
    - 关键词触发存储记忆
    """

    def __init__(self, memory_file: str = "memory_storage.json"):
        self.memory_file = memory_file
        self.memories = self._load_memories()

        # 存储触发关键词模式
        self.storage_patterns = [
            r"我是(.+?)，请为我存储这段记忆",
            r"请记住[：:]?(.+)",
            r"记住我是(.+)",
            r"存储记忆[：:]?(.+)",
            r"记住[：:]?(.+)",
            r"保存记忆[：:]?(.+)",
            r"我的记忆是[：:]?(.+)",
        ]

        # 检索触发关键词（可选，用于主动检索）
        self.retrieval_keywords = ["回忆", "记得", "我之前", "我说过"]

    def _load_memories(self) -> Dict:
        """加载记忆文件"""
        if os.path.exists(self.memory_file):
            try:
                with open(self.memory_file, 'r', encoding='utf-8') as f:
                    return json.load(f)
            except Exception as e:
                print(f"加载记忆文件出错: {e}")
                return {}
        return {}

    def _save_memories(self):
        """保存记忆到文件"""
        try:
            os.makedirs(os.path.dirname(self.memory_file) if os.path.dirname(self.memory_file) else '.', exist_ok=True)
            with open(self.memory_file, 'w', encoding='utf-8') as f:
                json.dump(self.memories, f, ensure_ascii=False, indent=2)
        except Exception as e:
            print(f"保存记忆文件出错: {e}")

    def store_memory(self, user_id: str, memory_content: str, category: str = "general") -> str:
        """存储用户记忆"""
        if user_id not in self.memories:
            self.memories[user_id] = []

        memory_entry = {
            "id": len(self.memories[user_id]) + 1,
            "content": memory_content.strip(),
            "category": category,
            "created_at": datetime.now().isoformat(),
            "updated_at": datetime.now().isoformat()
        }

        self.memories[user_id].append(memory_entry)
        self._save_memories()

        return f"✅ 记忆已保存 [ID: {memory_entry['id']}]"

    def retrieve_memories(self, user_id: str, query: str = None, limit: int = 10) -> List[Dict]:
        """检索用户记忆"""
        user_memories = self.memories.get(user_id, [])

        if not user_memories:
            return []

        # 如果提供了查询，进行简单匹配
        if query:
            matched = [m for m in user_memories if query.lower() in m['content'].lower()]
            return matched[-limit:]

        # 返回最近的记忆
        return user_memories[-limit:]

    def check_and_store(self, user_id: str, message: str) -> Tuple[bool, str]:
        """
        检查是否需要存储记忆
        返回: (是否存储成功, 响应消息)
        """
        for pattern in self.storage_patterns:
            match = re.search(pattern, message)
            if match:
                # 提取记忆内容
                if pattern.startswith(r"我是"):
                    memory_content = f"用户身份: {match.group(1).strip()}"
                else:
                    memory_content = match.group(1).strip()

                result = self.store_memory(user_id, memory_content)
                return True, result

        return False, ""

    def auto_retrieve(self, user_id: str, current_message: str = "") -> str:
        """
        自动检索记忆，生成上下文提示
        """
        memories = self.retrieve_memories(user_id)

        if not memories:
            return ""

        # 构建记忆上下文
        memory_context = "\n【用户记忆档案】\n"
        memory_context += f"用户ID: {user_id}\n"
        memory_context += f"共有 {len(self.memories.get(user_id, []))} 条记忆记录\n"
        memory_context += "=" * 40 + "\n"

        for i, mem in enumerate(memories, 1):
            memory_context += f"{i}. {mem['content']}\n"
            memory_context += f"   时间: {mem['created_at'][:10]}\n"

        memory_context += "=" * 40 + "\n"

        return memory_context

    def process_message(self, user_id: str, message: str) -> Dict:
        """
        处理用户消息的主入口
        1. 首先检查是否需要存储记忆
        2. 然后自动检索相关记忆
        """
        result = {
            "stored": False,
            "store_message": "",
            "memory_context": "",
            "original_message": message
        }

        # 步骤1: 检查是否触发存储
        stored, store_msg = self.check_and_store(user_id, message)
        result["stored"] = stored
        result["store_message"] = store_msg

        # 步骤2: 自动检索记忆（无论是否存储，都检索）
        memory_context = self.auto_retrieve(user_id, message)
        result["memory_context"] = memory_context

        return result

    def delete_memory(self, user_id: str, memory_id: int) -> str:
        """删除特定记忆"""
        if user_id in self.memories:
            self.memories[user_id] = [m for m in self.memories[user_id] if m['id'] != memory_id]
            self._save_memories()
            return f"✅ 记忆 ID:{memory_id} 已删除"
        return "❌ 未找到该记忆"

    def clear_all_memories(self, user_id: str) -> str:
        """清空用户所有记忆"""
        if user_id in self.memories:
            count = len(self.memories[user_id])
            self.memories[user_id] = []
            self._save_memories()
            return f"✅ 已清空 {count} 条记忆"
        return "❌ 该用户没有记忆记录"

    def get_memory_stats(self, user_id: str) -> Dict:
        """获取记忆统计信息"""
        user_memories = self.memories.get(user_id, [])
        return {
            "total_memories": len(user_memories),
            "categories": list(set(m['category'] for m in user_memories)),
            "first_memory": user_memories[0]['created_at'] if user_memories else None,
            "latest_memory": user_memories[-1]['created_at'] if user_memories else None
        }


class IntelligentMemoryAgent:
    """
    智能记忆Agent - 集成存储、检索、智能匹配于一体
    """

    def __init__(self, memory_file: str = "memory_storage.json"):
        self.agent = MemoryAgent(memory_file)
        self.user_context = {}  # 当前对话上下文

    def chat_with_memory(self, user_id: str, message: str) -> Dict:
        """
        带记忆的对话处理

        返回包含:
        - 是否存储了新记忆
        - 检索到的记忆上下文
        - 建议的系统提示词
        """
        # 1. 处理消息（存储+检索）
        result = self.agent.process_message(user_id, message)

        # 2. 构建系统提示词
        system_prompt = self._build_system_prompt(user_id, result)

        return {
            "user_id": user_id,
            "user_message": message,
            "stored_new_memory": result["stored"],
            "storage_confirmation": result["store_message"],
            "retrieved_memories": result["memory_context"],
            "system_prompt": system_prompt,
            "memory_count": len(self.agent.memories.get(user_id, []))
        }

    def _build_system_prompt(self, user_id: str, result: Dict) -> str:
        """构建包含记忆上下文的系统提示词"""

        base_prompt = """你是一个智能AI助手，你拥有记忆功能。在与用户对话时：
1. 记住用户的身份、偏好和重要信息
2. 根据用户的记忆提供个性化的回应
3. 保持自然、友好的对话风格
"""

        # 添加记忆上下文
        if result["memory_context"]:
            memory_section = f"""

【当前用户的记忆档案】
{result['memory_context']}

【记忆使用指南】
- 以上是该用户的历史记忆，请在回复中自然地运用这些信息
- 如果用户询问关于自己的信息，请基于这些记忆回答
- 保持对话的连贯性和个性化
"""
            return base_prompt + memory_section

        return base_prompt

    def get_formatted_memories(self, user_id: str) -> str:
        """获取格式化的记忆列表"""
        memories = self.agent.retrieve_memories(user_id)

        if not memories:
            return "暂无记忆记录"

        formatted = f"📚 {user_id} 的记忆档案\n"
        formatted += "=" * 50 + "\n"

        for mem in memories:
            formatted += f"\n📝 ID: {mem['id']}\n"
            formatted += f"   内容: {mem['content']}\n"
            formatted += f"   时间: {mem['created_at'][:19]}\n"

        formatted += "\n" + "=" * 50
        return formatted

    def search_memories(self, user_id: str, keyword: str) -> List[Dict]:
        """搜索特定关键词的记忆"""
        return self.agent.retrieve_memories(user_id, keyword)


# 便捷函数 - 快速集成
def create_memory_agent(memory_file: str = "memory_storage.json") -> IntelligentMemoryAgent:
    """创建记忆Agent实例"""
    return IntelligentMemoryAgent(memory_file)


def process_chat(user_id: str, message: str, memory_file: str = "memory_storage.json") -> Dict:
    """
    快速处理单条消息（无需管理Agent实例）

    示例:
        result = process_chat("user_123", "请记住我的名字是张三")
        print(result['system_prompt'])  # 用于AI模型的系统提示词
    """
    agent = create_memory_agent(memory_file)
    return agent.chat_with_memory(user_id, message)
