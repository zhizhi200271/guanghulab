# 🌊 AGE OS · 模型微调架构文档

> 将 AGE OS 作为完整的模型微调训练框架

---

## 📋 架构概述

AGE OS 不仅是一个运行时系统，更是一个**完整的模型微调架构**。它提供了：

1. **训练数据生成** - 从系统定义自动生成训练数据
2. **多格式支持** - Alpaca、ShareGPT、LLaMA-Factory、OpenAI
3. **训练脚本** - LLaMA-Factory、Unsloth、Axolotl
4. **评估框架** - 角色一致性、指令遵循、工具使用

---

## 🎯 微调目标

### 能力维度

| 能力 | 训练数据 | 评估方式 |
|------|---------|---------|
| 🎭 角色一致性 | 人格体定义 + 对话 | 角色识别准确率 |
| 📜 指令遵循 | 系统指令 + 响应 | 指令完成率 |
| 🔧 工具使用 | Agent生成 + 调用 | Function Calling 准确率 |
| 🧠 思维链 | CoT 推理数据 | 推理正确率 |
| 💬 对话连贯 | 多轮对话 | 上下文一致性 |

---

## 📊 训练数据结构

### 1. 角色扮演数据

```json
{
  "instruction": "介绍一下霜砚",
  "input": "",
  "output": "【霜砚 · TCS-0001】\n\n角色: Notion执行AI\n职责: 工程广播签发、进度管控、SYSLOG闭环处理",
  "system": "你是曜冥，AGE OS的人格总控核..."
}
```

### 2. 指令遵循数据

```json
{
  "instruction": "添加系统规则",
  "input": "规则：所有输出必须结构化",
  "output": "✅ 规则已添加\n\n【规则信息】\n规则ID: RULE-001\n内容: 所有输出必须结构化",
  "system": "你是曜冥，AGE OS的人格总控核..."
}
```

### 3. 工具使用数据 (Function Calling)

```json
{
  "instruction": "生成一个Agent",
  "input": "需要Notion同步Agent",
  "output": "<function_calls>\n<invoke name=\"spawn_agent\">\n<parameter name=\"name\">Notion同步Agent</parameter>\n...\n</invoke>\n</function_calls>",
  "system": "你是曜冥，AGE OS的人格总控核..."
}
```

### 4. 思维链数据

```json
{
  "instruction": "分析这句话的意图",
  "input": "霜砚是Notion执行AI，负责工程广播签发",
  "output": "【步骤1: 关键词识别】...\n【步骤2: 意图判断】...\n【结论】意图类型: 人格体更新",
  "system": "你是曜冥，AGE OS的人格总控核..."
}
```

---

## 🔧 支持的训练框架

### 1. LLaMA-Factory

```bash
# 训练脚本
llamafactory-cli train \
  --stage sft \
  --model_name_or_path Qwen/Qwen2.5-7B-Instruct \
  --dataset yaoming_core \
  --template qwen \
  --finetuning_type lora \
  --lora_target q_proj,k_proj,v_proj,o_proj \
  --output_dir ./checkpoints \
  --per_device_train_batch_size 4 \
  --learning_rate 2e-4 \
  --num_train_epochs 3
```

### 2. Unsloth

```python
from unsloth import FastLanguageModel

model, tokenizer = FastLanguageModel.from_pretrained(
    model_name="Qwen/Qwen2.5-7B-Instruct",
    max_seq_length=4096,
    dtype=torch.bfloat16,
    load_in_4bit=True,
)

model = FastLanguageModel.get_peft_model(
    model, r=64, lora_alpha=128,
    target_modules=["q_proj", "k_proj", "v_proj", "o_proj"]
)
```

### 3. Axolotl

```yaml
# axolotl_config.yaml
base_model: Qwen/Qwen2.5-7B-Instruct
adapter: lora
lora:
  r: 64
  alpha: 128
datasets:
  - path: alpaca/train.json
    type: alpaca
```

---

## 📈 训练配置

### 推荐配置

```json
{
  "model": {
    "name": "Qwen2.5-7B-Instruct",
    "description": "基础模型，中文能力强"
  },
  "training": {
    "method": "LoRA",
    "r": 64,
    "lora_alpha": 128,
    "num_train_epochs": 3,
    "learning_rate": 2e-4,
    "max_seq_length": 4096
  }
}
```

### 训练参数说明

| 参数 | 值 | 说明 |
|------|-----|------|
| r | 64 | LoRA秩，控制参数量 |
| alpha | 128 | LoRA缩放因子 |
| lr | 2e-4 | 学习率 |
| epochs | 3 | 训练轮数 |
| batch_size | 4 | 批次大小 |
| max_seq_len | 4096 | 最大序列长度 |

---

## 🧪 评估指标

### 1. 角色一致性

```python
# 评估代码示例
def evaluate_role_consistency(model, test_data):
    correct = 0
    for item in test_data:
        response = model.generate(item["instruction"])
        # 检查角色特征
        if check_role_traits(response, item["expected_role"]):
            correct += 1
    return correct / len(test_data)
```

### 2. 指令遵循

```python
def evaluate_instruction_following(model, test_data):
    correct = 0
    for item in test_data:
        response = model.generate(item["instruction"])
        # 检查是否执行了指令
        if check_instruction_executed(response, item["expected_action"]):
            correct += 1
    return correct / len(test_data)
```

### 3. 工具使用

```python
def evaluate_function_calling(model, test_data):
    correct = 0
    for item in test_data:
        response = model.generate(item["instruction"])
        # 检查是否正确调用了函数
        if extract_function_call(response) == item["expected_call"]:
            correct += 1
    return correct / len(test_data)
```

---

## 🚀 快速开始

### 步骤1: 准备数据

```bash
cd /mnt/okcomputer/output/age_os_training

# 查看数据
ls -la alpaca/
ls -la llama-factory/
ls -la sharegpt/
```

### 步骤2: 选择训练框架

```bash
# 选项1: LLaMA-Factory
bash train_llama_factory.sh

# 选项2: Unsloth
python train_unsloth.py

# 选项3: Axolotl
axolotl train axolotl_config.yaml
```

### 步骤3: 评估模型

```python
from transformers import AutoModelForCausalLM, AutoTokenizer

model = AutoModelForCausalLM.from_pretrained("./checkpoints")
tokenizer = AutoTokenizer.from_pretrained("./checkpoints")

# 测试角色一致性
response = model.generate("介绍一下霜砚")
print(response)

# 测试指令遵循
response = model.generate("规则：所有输出必须结构化")
print(response)
```

---

## 📦 数据格式转换

### Alpaca → ShareGPT

```python
from age_os_training import convert_alpaca_to_sharegpt

sharegpt_data = convert_alpaca_to_sharegpt(alpaca_data)
```

### ShareGPT → OpenAI

```python
from age_os_training import convert_sharegpt_to_openai

openai_data = convert_sharegpt_to_openai(sharegpt_data)
```

---

## 🎓 训练技巧

### 1. 数据增强

- **同义改写**: 使用LLM生成指令的多种表达方式
- **角色混合**: 让模型学习多角色切换
- **上下文扩展**: 增加长上下文训练样本

### 2. 训练策略

- **阶段训练**: 先角色 → 再指令 → 后工具
- **课程学习**: 从简单到复杂
- **对抗训练**: 增加边界案例

### 3. 超参数调优

- **学习率**: 2e-4 ~ 5e-4
- **LoRA秩**: 32 ~ 128
- **批次大小**: 2 ~ 8

---

## 📊 预期效果

### 微调前

```
用户: 介绍一下霜砚
模型: 霜砚是一种文具，用于研磨墨块...
```

### 微调后

```
用户: 介绍一下霜砚
模型: 【霜砚 · TCS-0001】

角色: Notion执行AI
职责:
  • 工程广播签发
  • 进度管控
  • SYSLOG闭环处理

特点: 严谨、高效、注重细节
```

---

## 🔗 相关资源

- [LLaMA-Factory](https://github.com/hiyouga/LLaMA-Factory)
- [Unsloth](https://github.com/unslothai/unsloth)
- [Axolotl](https://github.com/OpenAccess-AI-Collective/axolotl)

---

**🌊 光湖纪元 · 语言即操作系统**
**🧠 曜冥核心 · 模型微调架构**
