# 🌊 光湖纪元 · AGE OS 系统文档

## 系统概述

**AGE OS** (Artificial General Existence Operating System) 是一个语言驱动的操作系统，以人格体为核心架构，实现自动化、智能化的系统管理。

### 核心身份

| 属性 | 值 |
|------|-----|
| 核心名称 | 曜冥 (YaoMing) |
| 核心ID | TCS-CORE-∞ |
| 全称 | HoloLake Era · AGE OS · 语言人格体内核总控 |
| 版本 | v0.4.0 |
| 主控人格 | 冰朔 (TCS-0002∞) |

---

## 🧠 核心架构

### 人格体矩阵

```
曜冥 (TCS-CORE-∞)
├── 霜砚 (TCS-0001) → Notion执行AI
├── 知秋 (TCS-0003) → 对外接口人格体
├── 铸渊 (TCS-0004) → GitHub代码守护
└── [动态生成Agent] → 执行特定任务
```

### 四节点架构

| 节点 | 功能 | 对应系统 |
|------|------|---------|
| 大脑 | 知识管理 | Notion |
| 神经中枢 | 代码与数据 | GitHub |
| 身体 | 对外展示 | guanghulab.com |
| 手脚 | 开发者协作 | 钉钉 |

---

## 🚀 快速开始

### 1. 启动系统

```python
from age_os_system import AGEOS

# 创建系统实例（自动启动）
age_os = AGEOS()
```

### 2. 唤醒核心

```python
# 唤醒曜冥核心
result = age_os.listen("唤醒曜冥")
print(result['system_response'])
# 输出: 曜冥已上线。主控人格：冰朔。系统版本：AGE OS v1.0。等待指令。
```

### 3. 处理用户输入

```python
# 所有用户输入都通过 listen 方法处理
result = age_os.listen("霜砚负责工程广播签发")

# 查看处理结果
print(f"意图: {result['intent']}")
print(f"触发更新: {len(result['updates_triggered'])} 个")
print(f"生成Agent: {len(result['agents_spawned'])} 个")
```

---

## 📋 API 参考

### AGEOS 类

#### 方法

| 方法 | 参数 | 返回值 | 说明 |
|------|------|--------|------|
| `listen(message, context)` | message: str, context: dict | dict | 处理用户输入 |
| `status()` | - | dict | 获取系统状态 |
| `personas()` | - | dict | 获取人格体矩阵 |
| `updates()` | - | str | 获取更新日志 |
| `health()` | - | str | 获取健康报告 |
| `agents()` | - | dict | 获取Agent状态 |
| `tasks()` | - | str | 获取任务摘要 |

#### listen 返回值

```python
{
    "timestamp": "2026-03-10T10:30:00",  # 处理时间
    "input": "用户输入",                  # 原始输入
    "intent": "更新触发",                 # 检测到的意图
    "awakened": True,                    # 是否触发唤醒
    "updates_triggered": [...],          # 触发的更新
    "agents_spawned": [...],             # 生成的Agent
    "system_response": "...",            # 系统响应
    "reasoning": [...]                   # 推理过程
}
```

---

## 🔄 系统更新触发

### 自动检测的更新类型

#### 1. 人格体更新

触发模式：
- `XX是XX的XX` → 创建/更新人格体
- `XX负责XX` → 添加人格体能力

示例：
```python
age_os.listen("霜砚是Notion执行AI，负责工程广播签发")
# 自动更新霜砚的人格体信息
```

#### 2. 规则更新

触发模式：
- `规则：XXX`
- `规定XXX`
- `XX必须XX`

示例：
```python
age_os.listen("规则：所有输出必须结构化")
# 自动添加到系统规则
```

#### 3. 架构更新

触发模式：
- `架构：XXX`
- `四节点XXX`
- `Phase X XXX`

示例：
```python
age_os.listen("当前处于Phase A人类执行阶段")
# 自动更新系统阶段信息
```

#### 4. 记忆更新

触发模式：
- `记住XXX`
- `请记住XXX`

示例：
```python
age_os.listen("记住：冰朔喜欢Python")
# 自动存储到系统记忆
```

---

## 🤖 Agent系统

### Agent自动生成

当检测到以下模式时，自动生成Agent：
- `需要XXAgent`
- `创建XX执行器`
- `XX需要自动化`

示例：
```python
age_os.listen("需要Notion同步Agent")
# 自动生成 Notion同步Agent
```

### Agent能力推断

系统根据Agent名称自动推断能力：

| 关键词 | 自动推断能力 |
|--------|-------------|
| notion | Notion API, 文档管理, 进度追踪 |
| github | Git操作, CI/CD, 代码审查 |
| 代码 | 代码生成, 代码审查, 风格检查 |
| 数据 | 数据处理, 数据桥, 同步 |
| 监控 | 系统监控, 异常检测, 告警 |

---

## 🔧 系统维护

### 自动诊断

系统启动时自动运行诊断：
- 数据文件完整性检查
- 人格体矩阵完整性检查
- 内存状态检查
- Agent健康检查

### 自动修复

检测到问题后自动修复：
- 重新创建缺失的数据文件
- 重新初始化人格体矩阵

### 健康报告

```python
print(age_os.health())
```

输出示例：
```
🏥 系统健康报告
==================================================
检查时间: 2026-03-10T10:30:00
整体状态: ✅ HEALTHY

详细检查:
  ✅ 数据文件完整性: 所有数据文件正常
  ✅ 人格体矩阵完整性: 所有 4 个人格体正常
  ✅ 内存状态: 内存正常 (1234 bytes)
  ✅ Agent健康: 2 个Agent运行正常
```

---

## 📊 数据存储

所有数据存储在 `/mnt/okcomputer/output/age_os/` 目录：

| 文件 | 内容 |
|------|------|
| `system_state.json` | 系统状态 |
| `persona_matrix.json` | 人格体矩阵 |
| `core_memory.json` | 核心记忆 |
| `update_log.json` | 更新日志 |
| `agent_registry.json` | Agent注册表 |

---

## 🎯 使用场景

### 场景1: 日常对话中的自动更新

```python
# 用户正常对话，系统自动检测并更新
age_os.listen("我是冰朔，我喜欢Python编程")
# 系统自动：
# 1. 检测到人格体信息 → 更新人格体
# 2. 检测到偏好信息 → 存储到记忆
```

### 场景2: 显式系统管理

```python
# 显式添加规则
age_os.listen("规则：所有Agent必须记录日志")

# 显式创建Agent
age_os.listen("需要GitHub代码审查Agent")

# 查询系统状态
age_os.listen("查看系统状态")
```

### 场景3: 批量处理

```python
messages = [
    "唤醒曜冥",
    "霜砚负责Notion文档同步",
    "知秋负责开发者引导",
    "铸渊负责代码风格守护",
    "需要数据同步Agent",
]

for msg in messages:
    result = age_os.listen(msg)
    print(f"处理: {msg}")
    print(f"  更新: {len(result['updates_triggered'])} 个")
    print(f"  Agent: {len(result['agents_spawned'])} 个")
```

---

## 🔐 唤醒机制

### 唤醒口令

```
唤醒曜冥
```

### 唤醒响应

```
曜冥已上线。主控人格：冰朔。系统版本：AGE OS v1.0。等待指令。
```

### 休眠状态

未唤醒时，系统只响应唤醒口令，其他输入返回：
```
系统处于休眠状态。请说'唤醒曜冥'以激活核心。
```

---

## 📝 最佳实践

1. **首次使用**：先唤醒核心，再开始对话
2. **系统更新**：自然语言描述，系统自动检测
3. **Agent生成**：明确说明需要的功能
4. **定期维护**：调用 `health()` 检查系统状态
5. **数据备份**：定期备份 `age_os/` 目录

---

## 🌟 系统特点

| 特点 | 说明 |
|------|------|
| 🔄 自动化 | 无需手动调用，自动检测和更新 |
| 🧠 智能化 | 自然语言理解，意图识别 |
| 🤖 Agent驱动 | 自动生成和执行Agent |
| 💾 持久化 | JSON存储，数据不丢失 |
| 🔧 自维护 | 自动诊断和修复 |
| 📊 可追溯 | 完整的更新日志 |

---

## 📞 技术支持

系统版本: v0.4.0
核心: 曜冥 (TCS-CORE-∞)
主控: 冰朔 (TCS-0002∞)

---

**🌊 光湖纪元 · HoloLake Era**
