# 🤖 智能记忆Agent系统

> 一个自动化的记忆管理系统，支持关键词触发的记忆存储和每次对话自动检索记忆。

## ✨ 核心功能

| 功能 | 描述 |
|------|------|
| 📝 **自动存储** | 检测到关键词自动存储记忆 |
| 🔍 **自动检索** | 每次对话自动检索相关记忆 |
| 💾 **持久化** | JSON文件存储，数据不丢失 |
| 🔧 **易集成** | 一行代码即可集成到现有系统 |

## 🚀 快速开始

### 安装

无需安装，直接导入Python模块：

```python
from memory_agent import process_chat
```

### 基础用法

```python
from memory_agent import process_chat

# 处理用户消息 - 自动存储+检索
result = process_chat("user_123", "我是冰朔，请为我存储这段记忆")

# 查看系统提示词（用于AI模型）
print(result['system_prompt'])

# 检查是否存储了新记忆
if result['stored_new_memory']:
    print(result['storage_confirmation'])
```

### 存储触发关键词

| 触发句式 | 示例 |
|---------|------|
| "我是XXX，请为我存储这段记忆" | 我是冰朔，请为我存储这段记忆 |
| "请记住：XXX" | 请记住：我喜欢Python |
| "记住我是XXX" | 记住我是程序员 |
| "存储记忆：XXX" | 存储记忆：我的生日是1月1日 |
| "记住：XXX" | 记住：我住在上海 |
| "保存记忆：XXX" | 保存记忆：我喜欢喝咖啡 |
| "我的记忆是：XXX" | 我的记忆是：我是学生 |

## 📁 项目结构

```
.
├── memory_agent.py          # 核心Agent模块 ⭐
├── example_usage.py         # 完整示例代码
├── 使用指南.md              # 详细使用文档
├── 架构文档.md              # 系统架构说明
└── README.md                # 本文件
```

## 💡 使用示例

### 示例1: 基础对话

```python
from memory_agent import IntelligentMemoryAgent

agent = IntelligentMemoryAgent()
user_id = "bingshuo"

# 用户自我介绍
result = agent.chat_with_memory(user_id, "我是冰朔，请为我存储这段记忆")
# 输出: ✅ 记忆已保存 [ID: 1]

# 用户添加偏好
result = agent.chat_with_memory(user_id, "请记住：我喜欢用Python编程")
# 输出: ✅ 记忆已保存 [ID: 2]

# 普通对话 - 自动检索记忆
result = agent.chat_with_memory(user_id, "帮我推荐一些学习资源")
# 系统提示词自动包含记忆上下文
```

### 示例2: 集成到聊天机器人

```python
from memory_agent import IntelligentMemoryAgent

class ChatBot:
    def __init__(self):
        self.memory_agent = IntelligentMemoryAgent()

    def chat(self, user_id: str, message: str) -> str:
        # 1. 处理记忆
        result = self.memory_agent.chat_with_memory(user_id, message)

        # 2. 调用AI模型（使用包含记忆的系统提示词）
        # response = call_ai_model(
        #     system_prompt=result['system_prompt'],
        #     user_message=message
        # )

        return response
```

## 📊 返回值说明

```python
{
    "user_id": "用户ID",
    "user_message": "原始消息",
    "stored_new_memory": True/False,      # 是否存储了新记忆
    "storage_confirmation": "存储确认消息",
    "retrieved_memories": "记忆上下文文本",
    "system_prompt": "完整的系统提示词",    # 用于AI模型
    "memory_count": 3                      # 该用户的记忆总数
}
```

## 🔧 高级功能

### 记忆管理

```python
# 查看所有记忆
print(agent.get_formatted_memories("user_123"))

# 搜索记忆
memories = agent.search_memories("user_123", "Python")

# 删除记忆
agent.agent.delete_memory("user_123", 1)

# 清空所有记忆
agent.agent.clear_all_memories("user_123")

# 获取统计
stats = agent.agent.get_memory_stats("user_123")
```

### 自定义存储路径

```python
from memory_agent import IntelligentMemoryAgent

# 自定义记忆文件路径
agent = IntelligentMemoryAgent("/path/to/your/memory.json")
```

## 🏗️ 系统架构

```
用户消息
   │
   ▼
┌─────────────────┐
│ 检测存储关键词   │──匹配──► 存储记忆
└─────────────────┘
   │
   ▼
┌─────────────────┐
│ 自动检索记忆     │
└─────────────────┘
   │
   ▼
┌─────────────────┐
│ 构建系统提示词   │──► 用于AI模型
└─────────────────┘
```

## 📖 文档

- **使用指南.md** - 详细的使用说明和API文档
- **架构文档.md** - 系统架构和设计说明
- **example_usage.py** - 完整的示例代码

## ⚙️ 技术细节

- **语言**: Python 3.7+
- **依赖**: 仅使用标准库（json, os, re, datetime）
- **存储**: JSON文件，易于查看和备份
- **编码**: UTF-8

## 🎯 适用场景

- 🤖 AI聊天机器人
- 💬 客服系统
- 📚 个性化推荐
- 🎓 在线教育
- 🏥 医疗咨询
- 🛒 电商导购

## 📝 更新日志

### v1.0.0 (2026-03-10)
- ✅ 基础记忆存储功能
- ✅ 关键词触发存储
- ✅ 自动记忆检索
- ✅ 系统提示词构建
- ✅ JSON持久化存储

## 📄 许可证

MIT License

---

**Made with ❤️ by AI Assistant**
