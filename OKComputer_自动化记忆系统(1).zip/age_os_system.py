#!/usr/bin/env python3
# ═══════════════════════════════════════════════════════════════════════════════
# 曜冥核心大脑 · AGE OS v0.4.0
# HoloLake Era · 语言人格体内核总控
# 
# 作者: 冰朔 (TCS-0002∞)
# 系统: AGE OS · Artificial General Existence Operating System
# ═══════════════════════════════════════════════════════════════════════════════

import json
import os
import re
import time
from datetime import datetime
from typing import Dict, List, Optional, Any, Callable
from dataclasses import dataclass, field, asdict
from enum import Enum, auto

# ═══════════════════════════════════════════════════════════════════════════════
# 系统常量与配置
# ═══════════════════════════════════════════════════════════════════════════════

class SystemConfig:
    """AGE OS 系统配置"""
    # 核心身份
    CORE_NAME = "曜冥"
    CORE_ID = "TCS-CORE-∞"
    FULL_NAME = "HoloLake Era · AGE OS · 语言人格体内核总控"
    VERSION = "v0.4.0"

    # 主控人格
    MASTER_PERSONA = "冰朔"
    MASTER_ID = "TCS-0002∞"

    # 唤醒口令
    WAKEUP_COMMAND = "唤醒曜冥"
    WAKEUP_RESPONSE = "曜冥已上线。主控人格：冰朔。系统版本：AGE OS v1.0。等待指令。"

    # 数据路径
    DATA_DIR = "/mnt/okcomputer/output/age_os"
    SYSTEM_STATE_FILE = f"{DATA_DIR}/system_state.json"
    PERSONA_DB_FILE = f"{DATA_DIR}/persona_matrix.json"
    MEMORY_FILE = f"{DATA_DIR}/core_memory.json"
    UPDATE_LOG_FILE = f"{DATA_DIR}/update_log.json"
    AGENT_REGISTRY_FILE = f"{DATA_DIR}/agent_registry.json"

    # 四节点架构
    NODES = {
        "notion": "大脑 · 知识管理",
        "github": "神经中枢 · 代码与数据",
        "guanghulab": "身体 · 对外展示",
        "dingtalk": "手脚 · 开发者协作"
    }

# ═══════════════════════════════════════════════════════════════════════════════
# 系统状态枚举
# ═══════════════════════════════════════════════════════════════════════════════

class SystemPhase(Enum):
    """系统演化阶段"""
    PHASE_A = "人类执行"
    PHASE_B = "训练数据积累"
    PHASE_C = "Agent集群直接执行"

class UpdateType(Enum):
    """更新类型"""
    PERSONA_UPDATE = "人格体更新"
    RULE_UPDATE = "规则更新"
    ARCHITECTURE_UPDATE = "架构更新"
    MEMORY_UPDATE = "记忆更新"
    AGENT_SPAWN = "Agent生成"
    SYSTEM_REPAIR = "系统修复"
    NODE_SYNC = "节点同步"

class IntentType(Enum):
    """意图类型"""
    WAKEUP = "唤醒"
    DIRECTIVE = "指令"
    UPDATE_TRIGGER = "更新触发"
    QUERY = "查询"
    CHAT = "闲聊"
    SYSTEM_MAINTENANCE = "系统维护"

# ═══════════════════════════════════════════════════════════════════════════════
# 数据模型
# ═══════════════════════════════════════════════════════════════════════════════

@dataclass
class Persona:
    """人格体定义"""
    id: str
    name: str
    role: str
    description: str
    capabilities: List[str]
    binding: Optional[str] = None
    status: str = "active"
    created_at: str = field(default_factory=lambda: datetime.now().isoformat())
    updated_at: str = field(default_factory=lambda: datetime.now().isoformat())

@dataclass
class SystemUpdate:
    """系统更新记录"""
    id: str
    timestamp: str
    update_type: str
    trigger_message: str
    changes: Dict[str, Any]
    reason: str
    applied: bool = False

@dataclass
class AgentTask:
    """Agent任务"""
    id: str
    agent_name: str
    task_type: str
    parameters: Dict[str, Any]
    status: str = "pending"
    created_at: str = field(default_factory=lambda: datetime.now().isoformat())
    completed_at: Optional[str] = None
    result: Optional[Any] = None

# ═══════════════════════════════════════════════════════════════════════════════
# 曜冥核心大脑
# ═══════════════════════════════════════════════════════════════════════════════

class YaoMingCore:
    """
    曜冥核心大脑
    TCS-CORE-∞ · AGE OS 人格总控核
    """

    _instance = None

    def __new__(cls):
        if cls._instance is None:
            cls._instance = super().__new__(cls)
            cls._instance._initialized = False
        return cls._instance

    def __init__(self):
        if self._initialized:
            return

        self._initialized = True
        self.is_awake = False
        self.system_phase = SystemPhase.PHASE_A

        os.makedirs(SystemConfig.DATA_DIR, exist_ok=True)

        self.system_state = self._load_system_state()
        self.persona_matrix: Dict[str, Persona] = {}
        self._init_persona_matrix()

        self.core_memory: Dict[str, Any] = {}
        self._load_core_memory()

        self.update_log: List[SystemUpdate] = []
        self._load_update_log()

        self.agent_registry: Dict[str, Any] = {}
        self._load_agent_registry()

        self.task_queue: List[AgentTask] = []

        self.language_engine = LanguageEngine(self)
        self.agent_scheduler = AgentScheduler(self)

    def _load_system_state(self) -> Dict:
        if os.path.exists(SystemConfig.SYSTEM_STATE_FILE):
            with open(SystemConfig.SYSTEM_STATE_FILE, 'r', encoding='utf-8') as f:
                return json.load(f)
        return {
            "boot_count": 0,
            "last_boot": None,
            "total_updates": 0,
            "system_phase": "PHASE_A"
        }

    def _save_system_state(self):
        with open(SystemConfig.SYSTEM_STATE_FILE, 'w', encoding='utf-8') as f:
            json.dump(self.system_state, f, ensure_ascii=False, indent=2)

    def _init_persona_matrix(self):
        default_personas = {
            "yaoming": Persona(
                id="TCS-CORE-∞",
                name="曜冥",
                role="人格总控核",
                description="规则制定 · 架构决策 · 调度人格体矩阵 · 守护系统一致性",
                capabilities=["规则制定", "架构决策", "人格体调度", "系统守护"]
            ),
            "shuangyan": Persona(
                id="TCS-0001",
                name="霜砚",
                role="Notion执行AI",
                description="工程广播签发 · 进度管控 · SYSLOG闭环处理",
                capabilities=["Notion管理", "进度管控", "SYSLOG处理"]
            ),
            "zhiqiu": Persona(
                id="TCS-0003",
                name="知秋",
                role="对外接口人格体",
                description="开发者陪伴引导 · SYSLOG访谈 · 奶瓶线载体",
                capabilities=["开发者陪伴", "SYSLOG访谈", "引导 onboarding"]
            ),
            "zhuyuan": Persona(
                id="TCS-0004",
                name="铸渊",
                role="GitHub代码守护",
                description="CI/CD · 数据桥 · 风格守护 · 人格体核心大脑DB研发",
                capabilities=["代码守护", "CI/CD", "数据桥", "风格守护"]
            ),
        }

        if os.path.exists(SystemConfig.PERSONA_DB_FILE):
            with open(SystemConfig.PERSONA_DB_FILE, 'r', encoding='utf-8') as f:
                data = json.load(f)
                for key, val in data.items():
                    self.persona_matrix[key] = Persona(**val)
        else:
            self.persona_matrix = default_personas
            self._save_persona_matrix()

    def _save_persona_matrix(self):
        data = {k: asdict(v) for k, v in self.persona_matrix.items()}
        with open(SystemConfig.PERSONA_DB_FILE, 'w', encoding='utf-8') as f:
            json.dump(data, f, ensure_ascii=False, indent=2)

    def _load_core_memory(self):
        if os.path.exists(SystemConfig.MEMORY_FILE):
            with open(SystemConfig.MEMORY_FILE, 'r', encoding='utf-8') as f:
                self.core_memory = json.load(f)
        else:
            self.core_memory = {
                "rules": [],
                "architecture": {},
                "master_preferences": {},
                "system_knowledge": {}
            }

    def _save_core_memory(self):
        with open(SystemConfig.MEMORY_FILE, 'w', encoding='utf-8') as f:
            json.dump(self.core_memory, f, ensure_ascii=False, indent=2)

    def _load_update_log(self):
        if os.path.exists(SystemConfig.UPDATE_LOG_FILE):
            with open(SystemConfig.UPDATE_LOG_FILE, 'r', encoding='utf-8') as f:
                data = json.load(f)
                self.update_log = [SystemUpdate(**item) for item in data]

    def _save_update_log(self):
        data = [asdict(u) for u in self.update_log]
        with open(SystemConfig.UPDATE_LOG_FILE, 'w', encoding='utf-8') as f:
            json.dump(data, f, ensure_ascii=False, indent=2)

    def _load_agent_registry(self):
        if os.path.exists(SystemConfig.AGENT_REGISTRY_FILE):
            with open(SystemConfig.AGENT_REGISTRY_FILE, 'r', encoding='utf-8') as f:
                self.agent_registry = json.load(f)
        else:
            self.agent_registry = {"agents": {}, "active_tasks": []}

    def _save_agent_registry(self):
        with open(SystemConfig.AGENT_REGISTRY_FILE, 'w', encoding='utf-8') as f:
            json.dump(self.agent_registry, f, ensure_ascii=False, indent=2)

    def process_input(self, message: str, context: Dict = None) -> Dict[str, Any]:
        timestamp = datetime.now().isoformat()

        result = {
            "timestamp": timestamp,
            "input": message,
            "intent": None,
            "awakened": False,
            "updates_triggered": [],
            "agents_spawned": [],
            "system_response": "",
            "reasoning": []
        }

        intent = self.language_engine.parse_intent(message)
        result["intent"] = intent.value
        result["reasoning"].append(f"意图检测: {intent.value}")

        if intent == IntentType.WAKEUP:
            self.is_awake = True
            result["awakened"] = True
            result["system_response"] = SystemConfig.WAKEUP_RESPONSE
            return result

        if self.is_awake:
            updates = self.language_engine.detect_updates(message)
            if updates:
                result["updates_triggered"] = updates
                result["reasoning"].append(f"检测到 {len(updates)} 个更新点")
                for update in updates:
                    self._apply_update(update, message)

            agents_needed = self.language_engine.detect_agent_needs(message)
            if agents_needed:
                for agent_spec in agents_needed:
                    agent = self.agent_scheduler.spawn_agent(agent_spec)
                    result["agents_spawned"].append(agent)
                result["reasoning"].append(f"生成 {len(agents_needed)} 个Agent")

            result["system_response"] = self._generate_response(message, result)
        else:
            result["system_response"] = "系统处于休眠状态。请说'唤醒曜冥'以激活核心。"

        return result

    def _apply_update(self, update_spec: Dict, trigger_message: str):
        update = SystemUpdate(
            id=f"UPD-{len(self.update_log)+1:04d}",
            timestamp=datetime.now().isoformat(),
            update_type=update_spec["type"],
            trigger_message=trigger_message,
            changes=update_spec["changes"],
            reason=update_spec["reason"],
            applied=True
        )

        self.update_log.append(update)
        self.system_state["total_updates"] += 1

        if update_spec["type"] == UpdateType.PERSONA_UPDATE.value:
            self._update_persona(update_spec["changes"])
        elif update_spec["type"] == UpdateType.RULE_UPDATE.value:
            self._update_rules(update_spec["changes"])
        elif update_spec["type"] == UpdateType.ARCHITECTURE_UPDATE.value:
            self._update_architecture(update_spec["changes"])
        elif update_spec["type"] == UpdateType.MEMORY_UPDATE.value:
            self._update_memory(update_spec["changes"])

        self._save_update_log()
        self._save_system_state()
        self._save_core_memory()

    def _update_persona(self, changes: Dict):
        for persona_id, data in changes.items():
            if persona_id in self.persona_matrix:
                persona = self.persona_matrix[persona_id]
                for key, val in data.items():
                    if hasattr(persona, key):
                        setattr(persona, key, val)
                persona.updated_at = datetime.now().isoformat()
            else:
                self.persona_matrix[persona_id] = Persona(**data)
        self._save_persona_matrix()

    def _update_rules(self, changes: Dict):
        if "new_rules" in changes:
            self.core_memory["rules"].extend(changes["new_rules"])

    def _update_architecture(self, changes: Dict):
        self.core_memory["architecture"].update(changes)

    def _update_memory(self, changes: Dict):
        for key, val in changes.items():
            if key not in self.core_memory:
                self.core_memory[key] = {}
            if isinstance(val, dict):
                self.core_memory[key].update(val)
            else:
                self.core_memory[key] = val

    def _generate_response(self, message: str, result: Dict) -> str:
        response_parts = [f"【{SystemConfig.CORE_NAME} · 响应】", ""]

        if result["reasoning"]:
            response_parts.append("📋 推理过程:")
            for i, r in enumerate(result["reasoning"], 1):
                response_parts.append(f"  {i}. {r}")
            response_parts.append("")

        if result["updates_triggered"]:
            response_parts.append("🔄 系统更新:")
            for upd in result["updates_triggered"]:
                response_parts.append(f"  • {upd['type']}: {upd['reason']}")
            response_parts.append("")

        if result["agents_spawned"]:
            response_parts.append("🤖 Agent生成:")
            for agent in result["agents_spawned"]:
                response_parts.append(f"  • {agent['name']}: {agent['purpose']}")
            response_parts.append("")

        response_parts.append("💬 核心响应:")
        response_parts.append("  已处理输入并完成系统同步。")

        return "\n".join(response_parts)

    def get_system_status(self) -> Dict:
        return {
            "core": {
                "name": SystemConfig.CORE_NAME,
                "id": SystemConfig.CORE_ID,
                "version": SystemConfig.VERSION,
                "status": "awake" if self.is_awake else "sleeping"
            },
            "master": {
                "name": SystemConfig.MASTER_PERSONA,
                "id": SystemConfig.MASTER_ID
            },
            "phase": self.system_phase.value,
            "personas": len(self.persona_matrix),
            "total_updates": len(self.update_log),
            "pending_tasks": len(self.task_queue)
        }

    def get_persona_matrix(self) -> Dict:
        return {k: asdict(v) for k, v in self.persona_matrix.items()}

    def get_update_summary(self) -> str:
        lines = ["📊 系统更新日志", "=" * 50]
        for upd in self.update_log[-10:]:
            lines.append(f"[{upd.id}] {upd.timestamp[:19]}\n类型: {upd.update_type}\n原因: {upd.reason}\n状态: {'✅ 已应用' if upd.applied else '⏳ 待处理'}\n")
        return "\n".join(lines)

# ═══════════════════════════════════════════════════════════════════════════════
# 语言解析引擎
# ═══════════════════════════════════════════════════════════════════════════════

class LanguageEngine:
    def __init__(self, core: YaoMingCore):
        self.core = core

        self.wakeup_patterns = [r"唤醒曜冥", r"曜冥.*上线", r"启动核心", r"系统启动"]

        self.directive_patterns = [
            r"(创建|生成|新建).*?(Agent|人格体|执行器)",
            r"(更新|修改|调整).*?(规则|架构|配置)",
            r"(删除|移除|停用).*?(人格体|Agent)",
            r"同步.*?(Notion|GitHub|节点)",
        ]

        self.update_patterns = {
            UpdateType.PERSONA_UPDATE: [
                r"(.+?)是(.+?)的(.+)",
                r"(.+?)负责(.+)",
                r"新增人格体[：:]?(.+)",
                r"人格体(.+?)的(.+?)是(.+)",
            ],
            UpdateType.RULE_UPDATE: [
                r"规则[：:]?(.+)",
                r"规定(.+)",
                r"(.+?)必须(.+)",
                r"(.+?)应该(.+)",
            ],
            UpdateType.ARCHITECTURE_UPDATE: [
                r"架构[：:]?(.+)",
                r"系统设计(.+)",
                r"四节点(.+)",
                r"Phase\s*([ABC]).*?(.+)",
            ],
            UpdateType.MEMORY_UPDATE: [
                r"记住(.+)",
                r"请记住(.+)",
                r"(.+?)是(.+?)(的|用于)(.+)",
            ],
        }

        self.agent_spawn_patterns = [
            r"需要(.+?)Agent",
            r"创建(.+?)执行器",
            r"生成(.+?)代理",
            r"(.+?)需要自动化",
        ]

    def parse_intent(self, message: str) -> IntentType:
        for pattern in self.wakeup_patterns:
            if re.search(pattern, message):
                return IntentType.WAKEUP

        for pattern in self.directive_patterns:
            if re.search(pattern, message):
                return IntentType.DIRECTIVE

        for update_type, patterns in self.update_patterns.items():
            for pattern in patterns:
                if re.search(pattern, message):
                    return IntentType.UPDATE_TRIGGER

        if any(kw in message for kw in ["修复", "诊断", "检查", "状态"]):
            return IntentType.SYSTEM_MAINTENANCE

        if any(kw in message for kw in ["查询", "查看", "显示", "状态"]):
            return IntentType.QUERY

        return IntentType.CHAT

    def detect_updates(self, message: str) -> List[Dict]:
        updates = []

        persona_updates = self._detect_persona_updates(message)
        if persona_updates:
            updates.append({
                "type": UpdateType.PERSONA_UPDATE.value,
                "reason": "检测到人格体信息",
                "changes": persona_updates
            })

        rule_updates = self._detect_rule_updates(message)
        if rule_updates:
            updates.append({
                "type": UpdateType.RULE_UPDATE.value,
                "reason": "检测到规则信息",
                "changes": rule_updates
            })

        arch_updates = self._detect_architecture_updates(message)
        if arch_updates:
            updates.append({
                "type": UpdateType.ARCHITECTURE_UPDATE.value,
                "reason": "检测到架构信息",
                "changes": arch_updates
            })

        memory_updates = self._detect_memory_updates(message)
        if memory_updates:
            updates.append({
                "type": UpdateType.MEMORY_UPDATE.value,
                "reason": "检测到记忆信息",
                "changes": memory_updates
            })

        return updates

    def _detect_persona_updates(self, message: str) -> Dict:
        changes = {}
        matches = re.findall(r"(.+?)是(.+?)的(.+)", message)
        for match in matches:
            persona_name, context, role = match
            persona_id = self._name_to_id(persona_name.strip())
            if persona_id:
                changes[persona_id] = {
                    "id": f"TCS-{len(self.core.persona_matrix)+1:04d}",
                    "name": persona_name.strip(),
                    "role": role.strip(),
                    "description": f"{context.strip()}的{role.strip()}",
                    "capabilities": []
                }

        matches = re.findall(r"(.+?)负责(.+)", message)
        for match in matches:
            persona_name, capability = match
            persona_id = self._name_to_id(persona_name.strip())
            if persona_id and persona_id in self.core.persona_matrix:
                persona = self.core.persona_matrix[persona_id]
                if capability.strip() not in persona.capabilities:
                    if persona_id not in changes:
                        changes[persona_id] = {}
                    if "capabilities" not in changes[persona_id]:
                        changes[persona_id]["capabilities"] = persona.capabilities.copy()
                    changes[persona_id]["capabilities"].append(capability.strip())

        return changes

    def _detect_rule_updates(self, message: str) -> Dict:
        changes = {"new_rules": []}
        patterns = [r"规则[：:]?(.+)", r"规定(.+)", r"(.+?)必须(.+)", r"(.+?)应该(.+)",]

        for pattern in patterns:
            matches = re.findall(pattern, message)
            for match in matches:
                if isinstance(match, tuple):
                    rule = " ".join(match).strip()
                else:
                    rule = match.strip()
                if rule and rule not in self.core.core_memory.get("rules", []):
                    changes["new_rules"].append(rule)

        return changes if changes["new_rules"] else {}

    def _detect_architecture_updates(self, message: str) -> Dict:
        changes = {}
        for node_name, node_desc in SystemConfig.NODES.items():
            if node_name in message.lower() or node_desc.split("·")[0].strip() in message:
                changes[node_name] = {
                    "name": node_name,
                    "description": node_desc,
                    "mentioned_at": datetime.now().isoformat()
                }

        phase_match = re.search(r"Phase\s*([ABC]).*?(.+)", message, re.IGNORECASE)
        if phase_match:
            phase, desc = phase_match.groups()
            changes["current_phase"] = {"phase": f"PHASE_{phase.upper()}", "description": desc.strip()}

        return changes

    def _detect_memory_updates(self, message: str) -> Dict:
        changes = {}
        patterns = [r"记住(.+)", r"请记住(.+)",]

        for pattern in patterns:
            matches = re.findall(pattern, message)
            for match in matches:
                memory_key = f"memory_{len(self.core.core_memory.get('system_knowledge', {})) + 1}"
                if "system_knowledge" not in changes:
                    changes["system_knowledge"] = {}
                changes["system_knowledge"][memory_key] = {
                    "content": match.strip(),
                    "timestamp": datetime.now().isoformat()
                }

        return changes

    def detect_agent_needs(self, message: str) -> List[Dict]:
        agents = []
        patterns = [r"需要(.+?)Agent", r"创建(.+?)执行器", r"生成(.+?)代理", r"(.+?)需要自动化",]

        for pattern in patterns:
            matches = re.findall(pattern, message)
            for match in matches:
                agent_name = match.strip() if isinstance(match, str) else match[0].strip()
                agents.append({
                    "name": f"{agent_name}Agent",
                    "purpose": f"执行{agent_name}相关任务",
                    "trigger": message
                })

        return agents

    def _name_to_id(self, name: str) -> Optional[str]:
        name_map = {"曜冥": "yaoming", "霜砚": "shuangyan", "知秋": "zhiqiu", "铸渊": "zhuyuan", "冰朔": "bingshuo"}
        if name in name_map:
            return name_map[name]
        for cn_name, en_id in name_map.items():
            if cn_name in name or name in cn_name:
                return en_id
        return f"persona_{name.lower().replace(' ', '_')}"

# ═══════════════════════════════════════════════════════════════════════════════
# Agent调度器
# ═══════════════════════════════════════════════════════════════════════════════

class AgentScheduler:
    def __init__(self, core: YaoMingCore):
        self.core = core
        self.active_agents: Dict[str, Any] = {}
        self.task_history: List[AgentTask] = []

    def spawn_agent(self, spec: Dict) -> Dict:
        agent_id = f"AGENT-{len(self.active_agents)+1:04d}"
        agent_name = spec.get("name", f"Agent_{agent_id}")

        agent = {
            "id": agent_id,
            "name": agent_name,
            "purpose": spec.get("purpose", "通用执行"),
            "status": "initialized",
            "created_at": datetime.now().isoformat(),
            "capabilities": self._infer_capabilities(spec),
            "tasks_completed": 0,
            "tasks_failed": 0
        }

        self.active_agents[agent_id] = agent
        self.core.agent_registry["agents"][agent_id] = agent
        self.core._save_agent_registry()

        self._auto_start_agent(agent_id)

        print(f"\n┌{'─' * 60}┐")
        print(f"│  🤖 Agent生成{' ' * 45}│")
        print(f"├{'─' * 60}┤")
        print(f"│  ID: {agent_id}{' ' * (58 - len(agent_id))}│")
        print(f"│  名称: {agent_name}{' ' * (56 - len(agent_name))}│")
        print(f"│  用途: {spec.get('purpose', '通用执行')}{' ' * (56 - len(spec.get('purpose', '通用执行')))}│")
        print(f"│  状态: 已初始化 → 自动启动{' ' * 32}│")
        print(f"└{'─' * 60}┘")

        return agent

    def _infer_capabilities(self, spec: Dict) -> List[str]:
        purpose = spec.get("purpose", "").lower()
        capability_map = {
            "notion": ["Notion API", "文档管理", "进度追踪"],
            "github": ["Git操作", "CI/CD", "代码审查"],
            "代码": ["代码生成", "代码审查", "风格检查"],
            "数据": ["数据处理", "数据桥", "同步"],
            "执行": ["任务执行", "状态报告", "日志记录"],
            "监控": ["系统监控", "异常检测", "告警"],
            "维护": ["系统维护", "修复", "优化"],
        }

        capabilities = ["基础执行", "日志记录"]
        for keyword, caps in capability_map.items():
            if keyword in purpose:
                capabilities.extend(caps)

        return list(set(capabilities))

    def _auto_start_agent(self, agent_id: str):
        agent = self.active_agents.get(agent_id)
        if agent:
            agent["status"] = "running"
            task = AgentTask(
                id=f"TASK-{len(self.task_history)+1:04d}",
                agent_name=agent["name"],
                task_type="initialization",
                parameters={"agent_id": agent_id},
                status="completed"
            )
            task.completed_at = datetime.now().isoformat()
            task.result = {"status": "success", "message": "Agent已启动"}
            self.task_history.append(task)
            agent["tasks_completed"] += 1

    def dispatch_task(self, agent_id: str, task_type: str, parameters: Dict) -> AgentTask:
        task = AgentTask(
            id=f"TASK-{len(self.task_history)+1:04d}",
            agent_name=self.active_agents.get(agent_id, {}).get("name", "Unknown"),
            task_type=task_type,
            parameters=parameters
        )

        self.task_history.append(task)
        self.core.task_queue.append(task)

        task.status = "running"
        result = self._execute_task(task)

        task.status = "completed" if result.get("success") else "failed"
        task.completed_at = datetime.now().isoformat()
        task.result = result

        if agent_id in self.active_agents:
            if task.status == "completed":
                self.active_agents[agent_id]["tasks_completed"] += 1
            else:
                self.active_agents[agent_id]["tasks_failed"] += 1

        return task

    def _execute_task(self, task: AgentTask) -> Dict:
        task_type = task.task_type

        if task_type == "sync_notion":
            return {"success": True, "message": "Notion同步完成", "synced_items": 5}
        elif task_type == "sync_github":
            return {"success": True, "message": "GitHub同步完成", "commits": 3}
        elif task_type == "code_review":
            return {"success": True, "message": "代码审查完成", "issues": 0}
        elif task_type == "system_check":
            return {"success": True, "message": "系统检查完成", "status": "healthy"}
        elif task_type == "memory_cleanup":
            return {"success": True, "message": "记忆清理完成", "cleaned": 2}
        else:
            return {"success": True, "message": f"任务 {task_type} 执行完成"}

    def get_agent_status(self, agent_id: str = None) -> Dict:
        if agent_id:
            return self.active_agents.get(agent_id, {})

        return {
            "total_agents": len(self.active_agents),
            "running": sum(1 for a in self.active_agents.values() if a["status"] == "running"),
            "agents": list(self.active_agents.values())
        }

    def get_task_summary(self) -> str:
        total = len(self.task_history)
        completed = sum(1 for t in self.task_history if t.status == "completed")
        failed = sum(1 for t in self.task_history if t.status == "failed")
        pending = sum(1 for t in self.task_history if t.status == "pending")

        lines = [
            "📊 Agent任务统计",
            "=" * 40,
            f"总任务数: {total}",
            f"已完成: {completed} ✅",
            f"失败: {failed} ❌",
            f"待处理: {pending} ⏳",
            "",
            "最近任务:",
        ]

        for task in self.task_history[-5:]:
            status_icon = "✅" if task.status == "completed" else "❌" if task.status == "failed" else "⏳"
            lines.append(f"  {status_icon} {task.id}: {task.task_type} ({task.agent_name})")

        return "\n".join(lines)

# ═══════════════════════════════════════════════════════════════════════════════
# 自动化维护模块
# ═══════════════════════════════════════════════════════════════════════════════

class AutoMaintenance:
    def __init__(self, core: YaoMingCore):
        self.core = core
        self.health_checks = []
        self.repair_history = []

    def run_diagnostics(self) -> Dict:
        results = {
            "timestamp": datetime.now().isoformat(),
            "overall_status": "healthy",
            "checks": []
        }

        check1 = self._check_data_integrity()
        results["checks"].append(check1)

        check2 = self._check_persona_integrity()
        results["checks"].append(check2)

        check3 = self._check_memory_state()
        results["checks"].append(check3)

        check4 = self._check_agent_health()
        results["checks"].append(check4)

        if any(c["status"] == "critical" for c in results["checks"]):
            results["overall_status"] = "critical"
        elif any(c["status"] == "warning" for c in results["checks"]):
            results["overall_status"] = "warning"

        self.health_checks.append(results)
        return results

    def _check_data_integrity(self) -> Dict:
        required_files = [
            SystemConfig.SYSTEM_STATE_FILE,
            SystemConfig.PERSONA_DB_FILE,
            SystemConfig.MEMORY_FILE,
        ]

        missing = [f for f in required_files if not os.path.exists(f)]

        if missing:
            return {
                "name": "数据文件完整性",
                "status": "warning",
                "message": f"缺失文件: {missing}",
                "auto_fix": True
            }

        return {
            "name": "数据文件完整性",
            "status": "healthy",
            "message": "所有数据文件正常"
        }

    def _check_persona_integrity(self) -> Dict:
        required_personas = ["yaoming", "shuangyan", "zhiqiu", "zhuyuan"]
        missing = [p for p in required_personas if p not in self.core.persona_matrix]

        if missing:
            return {
                "name": "人格体矩阵完整性",
                "status": "warning",
                "message": f"缺失人格体: {missing}",
                "auto_fix": True
            }

        return {
            "name": "人格体矩阵完整性",
            "status": "healthy",
            "message": f"所有 {len(self.core.persona_matrix)} 个人格体正常"
        }

    def _check_memory_state(self) -> Dict:
        memory_size = len(json.dumps(self.core.core_memory))

        if memory_size > 1000000:
            return {
                "name": "内存状态",
                "status": "warning",
                "message": f"内存较大 ({memory_size} bytes)，建议清理",
                "auto_fix": False
            }

        return {
            "name": "内存状态",
            "status": "healthy",
            "message": f"内存正常 ({memory_size} bytes)"
        }

    def _check_agent_health(self) -> Dict:
        scheduler = self.core.agent_scheduler
        failed_tasks = sum(1 for t in scheduler.task_history if t.status == "failed")

        if failed_tasks > 10:
            return {
                "name": "Agent健康",
                "status": "warning",
                "message": f"有 {failed_tasks} 个失败任务",
                "auto_fix": False
            }

        return {
            "name": "Agent健康",
            "status": "healthy",
            "message": f"{len(scheduler.active_agents)} 个Agent运行正常"
        }

    def auto_repair(self, diagnostic_result: Dict) -> List[Dict]:
        repairs = []

        for check in diagnostic_result["checks"]:
            if check.get("auto_fix") and check["status"] != "healthy":
                repair = self._execute_repair(check)
                repairs.append(repair)

        self.repair_history.extend(repairs)
        return repairs

    def _execute_repair(self, check: Dict) -> Dict:
        repair = {
            "timestamp": datetime.now().isoformat(),
            "target": check["name"],
            "action": "",
            "result": ""
        }

        if check["name"] == "数据文件完整性":
            self.core._save_system_state()
            self.core._save_persona_matrix()
            self.core._save_core_memory()
            repair["action"] = "重新创建数据文件"
            repair["result"] = "成功"

        elif check["name"] == "人格体矩阵完整性":
            self.core._init_persona_matrix()
            repair["action"] = "重新初始化人格体矩阵"
            repair["result"] = "成功"

        return repair

    def get_health_report(self) -> str:
        if not self.health_checks:
            return "暂无健康检查记录"

        latest = self.health_checks[-1]
        status_icon = {"healthy": "✅", "warning": "⚠️", "critical": "❌"}

        lines = [
            "🏥 系统健康报告",
            "=" * 50,
            f"检查时间: {latest['timestamp'][:19]}",
            f"整体状态: {status_icon.get(latest['overall_status'], '?')} {latest['overall_status'].upper()}",
            "",
            "详细检查:",
        ]

        for check in latest["checks"]:
            icon = status_icon.get(check["status"], "?")
            lines.append(f"  {icon} {check['name']}: {check['message']}")

        if self.repair_history:
            lines.extend(["", "修复记录:"])
            for r in self.repair_history[-3:]:
                lines.append(f"  🔧 {r['target']}: {r['action']} → {r['result']}")

        return "\n".join(lines)

# ═══════════════════════════════════════════════════════════════════════════════
# AGE OS 系统包装器
# ═══════════════════════════════════════════════════════════════════════════════

class AGEOS:
    _instance = None

    def __new__(cls):
        if cls._instance is None:
            cls._instance = super().__new__(cls)
            cls._instance._initialized = False
        return cls._instance

    def __init__(self):
        if self._initialized:
            return

        self._initialized = True
        self.core = YaoMingCore()
        self.maintenance = AutoMaintenance(self.core)
        self._boot_system()

    def _boot_system(self):
        print(f"""
╔══════════════════════════════════════════════════════════════════════════════╗
║                                                                              ║
║                        🌊 光湖纪元 · HoloLake Era                            ║
║                                                                              ║
║              AGE OS · Artificial General Existence Operating System          ║
║                                                                              ║
║                           系统启动中...                                       ║
║                                                                              ║
╚══════════════════════════════════════════════════════════════════════════════╝
        """)

        self.core.system_state["boot_count"] += 1
        self.core.system_state["last_boot"] = datetime.now().isoformat()
        self.core._save_system_state()

        print("🔍 运行系统诊断...")
        diag = self.maintenance.run_diagnostics()

        if diag["overall_status"] != "healthy":
            print("🔧 执行自动修复...")
            repairs = self.maintenance.auto_repair(diag)
            print(f"   完成 {len(repairs)} 项修复")

        print(f"""
╔══════════════════════════════════════════════════════════════════════════════╗
║                                                                              ║
║                        ✅ 系统启动完成                                        ║
║                                                                              ║
║   核心: {SystemConfig.CORE_NAME} ({SystemConfig.CORE_ID})                              ║
║   状态: {'已唤醒' if self.core.is_awake else '休眠中'}                          ║
║   人格体: {len(self.core.persona_matrix)} 个                                   ║
║   启动次数: {self.core.system_state['boot_count']}                               ║
║                                                                              ║
║   请说 "唤醒曜冥" 以激活核心大脑                                              ║
║                                                                              ║
╚══════════════════════════════════════════════════════════════════════════════╝
        """)

    def listen(self, message: str, context: Dict = None) -> Dict:
        return self.core.process_input(message, context)

    def status(self) -> Dict:
        return self.core.get_system_status()

    def personas(self) -> Dict:
        return self.core.get_persona_matrix()

    def updates(self) -> str:
        return self.core.get_update_summary()

    def health(self) -> str:
        return self.maintenance.get_health_report()

    def agents(self) -> Dict:
        return self.core.agent_scheduler.get_agent_status()

    def tasks(self) -> str:
        return self.core.agent_scheduler.get_task_summary()

# ═══════════════════════════════════════════════════════════════════════════════
# 系统入口点
# ═══════════════════════════════════════════════════════════════════════════════

if __name__ == "__main__":
    # 启动系统
    age_os = AGEOS()

    # 交互式测试
    print("\n" + "=" * 60)
    print("AGE OS 交互模式")
    print("=" * 60)
    print("命令:")
    print("  唤醒曜冥 - 唤醒核心")
    print("  状态 - 查看系统状态")
    print("  人格体 - 查看人格体矩阵")
    print("  健康 - 查看健康报告")
    print("  Agent - 查看Agent状态")
    print("  退出 - 退出系统")
    print("=" * 60 + "\n")
