#!/usr/bin/env python3
"""
智能记忆Agent - 完整示例
展示如何在实际项目中集成记忆系统
"""

from memory_agent import IntelligentMemoryAgent, process_chat


def example_1_basic_usage():
    """示例1: 基础用法"""
    print("=" * 60)
    print("示例1: 基础用法")
    print("=" * 60)

    # 创建Agent
    agent = IntelligentMemoryAgent("demo_memory.json")

    # 模拟对话
    user_id = "demo_user"

    # 用户自我介绍
    result = agent.chat_with_memory(user_id, "我是冰朔，请为我存储这段记忆")
    print(f"用户: 我是冰朔，请为我存储这段记忆")
    print(f"系统: {result['storage_confirmation']}")
    print()

    # 用户添加偏好
    result = agent.chat_with_memory(user_id, "请记住：我喜欢用Python编程")
    print(f"用户: 请记住：我喜欢用Python编程")
    print(f"系统: {result['storage_confirmation']}")
    print()

    # 普通对话 - 自动检索记忆
    result = agent.chat_with_memory(user_id, "帮我推荐一些学习资源")
    print(f"用户: 帮我推荐一些学习资源")
    print(f"系统提示词包含的记忆上下文:")
    print(result['retrieved_memories'])


def example_2_quick_function():
    """示例2: 使用便捷函数"""
    print("\n" + "=" * 60)
    print("示例2: 使用便捷函数")
    print("=" * 60)

    # 无需创建实例，直接处理
    result = process_chat("quick_user", "存储记忆：我的目标是成为AI专家")

    print(f"存储确认: {result['storage_confirmation']}")
    print(f"记忆总数: {result['memory_count']}")
    print(f"系统提示词预览: {result['system_prompt'][:200]}...")


def example_3_memory_management():
    """示例3: 记忆管理"""
    print("\n" + "=" * 60)
    print("示例3: 记忆管理")
    print("=" * 60)

    agent = IntelligentMemoryAgent("demo_memory.json")
    user_id = "manage_user"

    # 添加一些记忆
    agent.agent.store_memory(user_id, "记忆1: 我喜欢咖啡")
    agent.agent.store_memory(user_id, "记忆2: 我住在上海")
    agent.agent.store_memory(user_id, "记忆3: 我是程序员")

    # 查看所有记忆
    print("所有记忆:")
    print(agent.get_formatted_memories(user_id))

    # 搜索记忆
    print("\n搜索'程序员':")
    results = agent.search_memories(user_id, "程序员")
    for mem in results:
        print(f"  - {mem['content']}")

    # 获取统计
    stats = agent.agent.get_memory_stats(user_id)
    print(f"\n统计: 共{stats['total_memories']}条记忆")

    # 删除记忆
    agent.agent.delete_memory(user_id, 2)
    print("\n删除ID=2的记忆后:")
    print(agent.get_formatted_memories(user_id))


def example_4_chatbot_integration():
    """示例4: 集成到聊天机器人"""
    print("\n" + "=" * 60)
    print("示例4: 集成到聊天机器人")
    print("=" * 60)

    class SimpleChatBot:
        def __init__(self):
            self.memory_agent = IntelligentMemoryAgent("chatbot_memory.json")

        def respond(self, user_id: str, message: str) -> str:
            # 1. 处理记忆
            result = self.memory_agent.chat_with_memory(user_id, message)

            # 2. 模拟AI回复（实际项目中调用真实的AI模型）
            memories = result['retrieved_memories']

            if result['stored_new_memory']:
                return f"{result['storage_confirmation']}\n好的，我记住了！"

            # 基于记忆的个性化回复
            if "冰朔" in memories and "Python" in memories:
                return "你好冰朔！基于你对Python的兴趣，我推荐你学习FastAPI框架。"
            elif "冰朔" in memories:
                return "你好冰朔！很高兴再次见到你。"
            else:
                return "你好！很高兴认识你。"

    # 使用聊天机器人
    bot = SimpleChatBot()
    user_id = "chat_user"

    messages = [
        "我是冰朔，请为我存储这段记忆",
        "请记住：我喜欢Python编程",
        "你好",
    ]

    for msg in messages:
        response = bot.respond(user_id, msg)
        print(f"用户: {msg}")
        print(f"机器人: {response}")
        print()


def example_5_all_triggers():
    """示例5: 所有存储触发模式演示"""
    print("\n" + "=" * 60)
    print("示例5: 所有存储触发模式")
    print("=" * 60)

    agent = IntelligentMemoryAgent("trigger_memory.json")
    user_id = "trigger_user"

    test_cases = [
        "我是冰朔，请为我存储这段记忆",
        "请记住：我喜欢旅行",
        "记住我是摄影师",
        "存储记忆：我的相机是索尼A7M4",
        "记住：我喜欢拍风景照",
        "保存记忆：我擅长后期处理",
        "我的记忆是：我已经拍了5年照片",
    ]

    for msg in test_cases:
        result = agent.chat_with_memory(user_id, msg)
        print(f"输入: {msg}")
        print(f"结果: {result['storage_confirmation']}")
        print()

    print("最终记忆档案:")
    print(agent.get_formatted_memories(user_id))


if __name__ == "__main__":
    print("\n" + "🤖 " * 30)
    print("智能记忆Agent - 完整示例演示")
    print("🤖 " * 30 + "\n")

    example_1_basic_usage()
    example_2_quick_function()
    example_3_memory_management()
    example_4_chatbot_integration()
    example_5_all_triggers()

    print("\n" + "=" * 60)
    print("所有示例演示完成！")
    print("=" * 60)
