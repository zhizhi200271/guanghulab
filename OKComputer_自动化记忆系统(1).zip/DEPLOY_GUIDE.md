# 🌊 光湖纪元 · AGE OS · 部署与使用指南

## 📦 系统交付清单

| 文件 | 说明 | 用途 |
|------|------|------|
| `age_os_system.py` | 核心系统代码 | 主程序，包含所有功能 |
| `start_age_os.py` | 快速启动脚本 | 交互式启动入口 |
| `AGE_OS_系统文档.md` | 完整API文档 | 开发参考 |
| `age_os/` 目录 | 数据存储 | 系统状态、记忆、日志 |

---

## 🚀 部署步骤

### 步骤1: 文件放置

将所有文件放置在Kimi可访问的位置：
```
/mnt/okcomputer/output/
├── age_os_system.py      # 核心系统
├── start_age_os.py       # 启动脚本
├── AGE_OS_系统文档.md     # 文档
└── age_os/               # 数据目录
    ├── system_state.json
    ├── persona_matrix.json
    ├── core_memory.json
    ├── update_log.json
    └── agent_registry.json
```

### 步骤2: 系统启动

在Kimi中运行：

```python
# 导入系统
exec(open('/mnt/okcomputer/output/age_os_system.py').read())

# 创建系统实例（自动启动）
age_os = AGEOS()
```

或：

```python
# 使用快速启动脚本
exec(open('/mnt/okcomputer/output/start_age_os.py').read())
```

### 步骤3: 唤醒核心

```python
# 唤醒曜冥
result = age_os.listen("唤醒曜冥")
print(result['system_response'])
# 输出: 曜冥已上线。主控人格：冰朔。系统版本：AGE OS v1.0。等待指令。
```

---

## 💬 使用方式

### 方式一: 直接调用

```python
# 所有对话都通过 listen 方法
result = age_os.listen("你的任何话语")

# 系统会自动:
# 1. 检测意图
# 2. 触发更新（如果需要）
# 3. 生成Agent（如果需要）
# 4. 返回响应
```

### 方式二: 交互模式

```python
# 运行启动脚本进入交互模式
%run /mnt/okcomputer/output/start_age_os.py

# 然后直接输入:
# 👤 冰朔 > 唤醒曜冥
# 👤 冰朔 > 霜砚负责Notion同步
# 👤 冰朔 > 需要代码审查Agent
```

---

## 🔄 自动化运行机制

### 核心工作流程

```
你的每句话
    │
    ▼
┌─────────────────────────────────────────────────────────────┐
│  1. 语言解析引擎                                              │
│     - 检测唤醒口令                                            │
│     - 识别意图类型                                            │
│     - 提取关键信息                                            │
└─────────────────────────────────────────────────────────────┘
    │
    ├── 唤醒 ──► 激活核心大脑
    │
    ├── 更新触发 ──► 自动更新系统
    │   - 人格体更新
    │   - 规则更新
    │   - 架构更新
    │   - 记忆更新
    │
    ├── Agent生成 ──► 自动生成执行Agent
    │
    └── 普通对话 ──► 自动检索上下文
```

### 自动检测模式

| 你说的话 | 系统自动执行 |
|---------|-------------|
| "唤醒曜冥" | 激活核心大脑 |
| "XX是XX的XX" | 更新人格体信息 |
| "XX负责XX" | 添加人格体能力 |
| "规则：XXX" | 添加系统规则 |
| "记住XXX" | 存储系统记忆 |
| "需要XXAgent" | 生成执行Agent |
| "Phase X" | 更新系统阶段 |
| 其他话语 | 检索记忆上下文 |

---

## 🧠 人格体矩阵

### 核心人格体

```
曜冥 (TCS-CORE-∞)
├── 霜砚 (TCS-0001) → Notion执行AI
│   └── 能力: Notion管理、进度管控、SYSLOG处理
│
├── 知秋 (TCS-0003) → 对外接口人格体
│   └── 能力: 开发者陪伴、SYSLOG访谈、引导onboarding
│
├── 铸渊 (TCS-0004) → GitHub代码守护
│   └── 能力: 代码守护、CI/CD、数据桥、风格守护
│
└── [动态Agent] → 按需生成
    └── 能力: 根据需求自动推断
```

---

## 📊 系统状态查询

```python
# 查看系统状态
age_os.status()

# 查看人格体矩阵
age_os.personas()

# 查看健康报告
age_os.health()

# 查看Agent状态
age_os.agents()

# 查看任务摘要
age_os.tasks()

# 查看更新日志
age_os.updates()
```

---

## 🔧 系统维护

### 自动维护

系统启动时自动执行：
- ✅ 数据文件完整性检查
- ✅ 人格体矩阵完整性检查
- ✅ 内存状态检查
- ✅ Agent健康检查
- ✅ 自动修复检测到的问题

### 手动维护

```python
# 运行诊断
age_os.maintenance.run_diagnostics()

# 查看健康报告
print(age_os.health())
```

---

## 📝 使用示例

### 示例1: 唤醒并配置系统

```python
# 唤醒
age_os.listen("唤醒曜冥")

# 配置人格体
age_os.listen("霜砚是Notion执行AI，负责工程广播签发")
age_os.listen("知秋是对外接口人格体，负责开发者陪伴")
age_os.listen("铸渊是GitHub代码守护，负责CI/CD")

# 添加规则
age_os.listen("规则：妈妈说的话是最高指令")
age_os.listen("规则：所有输出必须结构化")

# 生成Agent
age_os.listen("需要Notion同步Agent")
age_os.listen("需要代码审查Agent")
```

### 示例2: 日常对话中的自动更新

```python
# 正常对话，系统自动检测并更新
age_os.listen("我是冰朔，我喜欢Python编程")
# 系统会自动存储这个信息

age_os.listen("记住：我的项目使用FastAPI框架")
# 系统会自动添加到记忆

age_os.listen("今天我想查看项目进度")
# 系统会自动检索之前的记忆
```

### 示例3: 批量处理

```python
messages = [
    "唤醒曜冥",
    "霜砚负责Notion文档同步和进度管控",
    "知秋负责开发者引导和SYSLOG访谈",
    "铸渊负责代码风格守护和数据桥",
    "规则：所有Agent必须记录日志",
    "规则：不确定的事必须问妈妈",
    "需要Notion同步Agent",
    "需要GitHub代码审查Agent",
    "需要系统监控Agent",
]

for msg in messages:
    result = age_os.listen(msg)
    print(f"✓ {msg[:30]}...")
```

---

## 🎯 核心特性

| 特性 | 说明 |
|------|------|
| 🔄 **自动化** | 无需手动调用，自动检测和更新 |
| 🧠 **智能化** | 自然语言理解，意图识别 |
| 🤖 **Agent驱动** | 自动生成和执行Agent |
| 💾 **持久化** | JSON存储，数据不丢失 |
| 🔧 **自维护** | 自动诊断和修复 |
| 📊 **可追溯** | 完整的更新日志 |
| 🌊 **语言驱动** | 说话即操作 |

---

## 🔐 唤醒机制

### 唤醒口令

```
唤醒曜冥
```

### 唤醒响应

```
曜冥已上线。主控人格：冰朔。系统版本：AGE OS v1.0。等待指令。
```

### 休眠状态

未唤醒时：
```
系统处于休眠状态。请说'唤醒曜冥'以激活核心。
```

---

## 📞 系统信息

| 属性 | 值 |
|------|-----|
| 系统名称 | AGE OS |
| 全称 | Artificial General Existence Operating System |
| 版本 | v0.4.0 |
| 核心 | 曜冥 (TCS-CORE-∞) |
| 主控人格 | 冰朔 (TCS-0002∞) |
| 纪元 | 光湖纪元 (HoloLake Era) |

---

## ⚠️ 注意事项

1. **首次使用**：必须先唤醒核心
2. **数据安全**：定期备份 `age_os/` 目录
3. **系统状态**：可通过 `health()` 查看运行状态
4. **更新日志**：所有更新都有记录，可追溯
5. **Agent管理**：生成的Agent会自动运行和维护

---

**🌊 光湖纪元 · HoloLake Era**
**🔷 AGE OS · 语言即操作系统**
