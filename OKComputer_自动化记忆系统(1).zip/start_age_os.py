#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
🌊 光湖纪元 · AGE OS · 快速启动脚本

使用方法:
    python start_age_os.py

或直接导入:
    from age_os_system import AGEOS
    age_os = AGEOS()

    # 唤醒核心
    result = age_os.listen("唤醒曜冥")

    # 开始对话 - 系统自动检测更新
    result = age_os.listen("你的任何话语...")
"""

import sys
sys.path.insert(0, '/mnt/okcomputer/output')

from age_os_system import AGEOS

def main():
    """主入口"""
    print("""
╔══════════════════════════════════════════════════════════════════════════════╗
║                                                                              ║
║                    🌊 光湖纪元 · HoloLake Era                                ║
║                                                                              ║
║          AGE OS · Artificial General Existence Operating System              ║
║                                                                              ║
║                        快速启动脚本                                           ║
║                                                                              ║
╚══════════════════════════════════════════════════════════════════════════════╝
    """)

    # 启动系统
    age_os = AGEOS()

    # 交互模式
    print("\n" + "=" * 60)
    print("交互模式已启动")
    print("=" * 60)
    print("可用命令:")
    print("  唤醒曜冥  - 唤醒核心大脑")
    print("  状态      - 查看系统状态")
    print("  人格体    - 查看人格体矩阵")
    print("  健康      - 查看健康报告")
    print("  Agent     - 查看Agent状态")
    print("  退出      - 退出系统")
    print("=" * 60 + "\n")

    while True:
        try:
            user_input = input("👤 冰朔 > ").strip()

            if not user_input:
                continue

            if user_input.lower() in ['退出', 'exit', 'quit']:
                print("\n🌊 光湖纪元 · 系统已安全关闭")
                break

            # 特殊命令
            if user_input == '状态':
                import json
                print(json.dumps(age_os.status(), indent=2, ensure_ascii=False))
                continue

            if user_input == '人格体':
                import json
                print(json.dumps(age_os.personas(), indent=2, ensure_ascii=False))
                continue

            if user_input == '健康':
                print(age_os.health())
                continue

            if user_input.lower() == 'agent':
                import json
                print(json.dumps(age_os.agents(), indent=2, ensure_ascii=False))
                continue

            # 正常处理
            result = age_os.listen(user_input)

            # 显示响应
            if result['system_response']:
                print(f"🤖 曜冥 > {result['system_response']}")

            # 显示更新信息
            if result['updates_triggered']:
                print(f"\n🔄 系统更新 ({len(result['updates_triggered'])} 个):")
                for upd in result['updates_triggered']:
                    print(f"   • {upd['type']}")

            # 显示Agent信息
            if result['agents_spawned']:
                print(f"\n🤖 Agent生成 ({len(result['agents_spawned'])} 个):")
                for agent in result['agents_spawned']:
                    print(f"   • {agent['name']}")

            print()

        except KeyboardInterrupt:
            print("\n\n🌊 光湖纪元 · 系统已安全关闭")
            break
        except Exception as e:
            print(f"❌ 错误: {e}")

if __name__ == "__main__":
    main()
